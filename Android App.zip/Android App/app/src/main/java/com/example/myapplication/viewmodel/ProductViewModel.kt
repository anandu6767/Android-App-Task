package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MyApplication.model.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.myapp.model.Product
import com.example.myapp.repository.ProductRepository

class ProductViewModel(private val repository: ProductRepository) : ViewModel() {
    // StateFlow for product details
    private val _productDetail = MutableStateFlow<Product?>(null)
    val productDetail: StateFlow<Product?> get() = _productDetail

    // Function to fetch product detail by ID
    fun fetchProductDetail(id: Int) {
        viewModelScope.launch {
            val product = repository.getProductDetail(id)
            _productDetail.value = product
        }
    }

    // You can add other properties and methods for pagination here if needed
}
