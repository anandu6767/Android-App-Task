package com.example.myapp.network

import com.example.appname.model.Product
import com.example.appname.model.ProductResponse
import com.example.myapp.model.Product
import com.example.myapp.model.ProductResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("products")
    suspend fun getProducts(
        @Query("limit") limit: Int,
        @Query("skip") skip: Int
    ): ProductResponse

    @GET("products/{id}")
    suspend fun getProductDetail(@Path("id") id: Int): Product
}
