package com.example.myapp.paging

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.appname.model.Product
import com.example.myapp.repository.ProductRepository

class ProductPagingSource(private val repository: ProductRepository) : PagingSource<Int, Product>() {
    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Product> {
        return try {
            val currentPage = params.key ?: 0
            val response = repository.getProducts(10, currentPage * 10)
            LoadResult.Page(
                data = response.products,
                prevKey = if (currentPage == 0) null else currentPage - 1,
                nextKey = if (response.products.isEmpty()) null else currentPage + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, Product>): Int? {
        TODO("Not yet implemented")
    }
}
