package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.model.Product
import com.example.myapplication.viewmodel.ProductViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

// ProductItem Composable
@Composable
fun ProductItem(product: Product, onClick: (Int) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth() // Changed to fillMaxWidth for better layout
            .padding(8.dp)
            .clickable { onClick(product.id) },
        elevation = CardDefaults.elevatedCardElevation()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = product.title, style = MaterialTheme.typography.titleMedium)
            // Add more product details if needed
        }
    }
}

// ProductList Composable
@Composable
fun ProductList(viewModel: ProductViewModel, modifier: Modifier = Modifier) {
    val products by viewModel.products.collectAsState(initial = emptyList())

    LazyColumn(modifier = modifier) {
        items(products) { product ->
            ProductItem(product = product) { id ->
                // Start DetailActivity when an item is clicked
                val context = LocalContext.current
                val intent = Intent(context, DetailActivity::class.java).apply {
                    putExtra("PRODUCT_ID", id)
                }
                context.startActivity(intent)
            }
        }
    }
}

// DetailActivity
class DetailActivity : ComponentActivity() {
    private val viewModel: ProductViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val productId = intent.getIntExtra("PRODUCT_ID", -1)

            // Fetch product details
            LaunchedEffect(productId) {
                if (productId != -1) {
                    viewModel.fetchProductDetail(productId)
                }
            }

            val product by viewModel.productDetail.collectAsState(initial = null)

            ProductDetailScreen(product)
        }
    }
}

// ProductDetailScreen Composable
@Composable
fun ProductDetailScreen(product: Product?) {
    Scaffold { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
            if (product != null) {
                Text(text = product.title, style = MaterialTheme.typography.headlineLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = product.description, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Price: ${product.price}", style = MaterialTheme.typography.bodyMedium)
            } else {
                Text(text = "Loading...")
            }
        }
    }
}

// Preview for ProductDetailScreen
@Preview(showBackground = true)
@Composable
fun ProductDetailScreenPreview() {
    ProductDetailScreen(product = Product(1, "Sample Product", "This is a sample product.", 19.99, "thumbnail_url"))
}
