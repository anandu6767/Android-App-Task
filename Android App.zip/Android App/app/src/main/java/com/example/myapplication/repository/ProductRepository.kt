package com.example.myapp.repository

import com.example.myapp.model.Product
import com.example.myapp.model.ProductResponse
import com.example.myapp.network.ServiceBuilder

class ProductRepository {
    private val apiService = ServiceBuilder.apiService

    suspend fun getProducts(limit: Int, skip: Int): ProductResponse {
        return apiService.getProducts(limit, skip)
    }

    suspend fun getProductDetail(id: Int): Product {
        return apiService.getProductDetail(id)
    }
}
